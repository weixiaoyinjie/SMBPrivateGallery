package com.privategallery.smb;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/** In-app image manipulation; never invokes external photo-viewing apps. */
final class ZoomImageView extends View {
    interface SwipeListener { void onSwipe(int direction); }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final ScaleGestureDetector pinch;
    private final GestureDetector gesture;
    private SwipeListener swipeListener;
    private Bitmap bitmap;
    private float zoom = 1f;
    private float offsetX = 0f, offsetY = 0f;
    private int rotation = 0;

    ZoomImageView(Context context) {
        super(context);
        setBackgroundColor(Color.BLACK);
        pinch = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                setZoom(zoom * detector.getScaleFactor());
                return true;
            }
        });
        gesture = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (zoom > 1.05f) resetZoom();
                else setZoom(2.5f);
                return true;
            }
            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2,
                                               float distanceX, float distanceY) {
                if (zoom > 1.05f && !pinch.isInProgress()) {
                    offsetX -= distanceX;
                    offsetY -= distanceY;
                    invalidate();
                    return true;
                }
                return false;
            }
            @Override public boolean onFling(MotionEvent e1, MotionEvent e2,
                                              float velocityX, float velocityY) {
                if (zoom > 1.05f || pinch.isInProgress() ||
                        e1 == null || e2 == null || swipeListener == null) return false;
                float dx = e2.getX() - e1.getX();
                if (Math.abs(dx) > 65 * getResources().getDisplayMetrics().density &&
                        Math.abs(velocityX) > 300 && Math.abs(dx) > Math.abs(e2.getY() - e1.getY())) {
                    swipeListener.onSwipe(dx < 0 ? 1 : -1);
                    return true;
                }
                return false;
            }
        });
    }

    void setSwipeListener(SwipeListener listener) { swipeListener = listener; }

    /** Viewer owns bitmaps and releases old buffers as soon as possible. */
    void setBitmap(Bitmap value) {
        Bitmap old = bitmap;
        bitmap = value;
        if (old != null && old != value && !old.isRecycled()) old.recycle();
        rotation = 0;
        resetZoom();
    }

    void zoomIn() { setZoom(zoom * 1.5f); }
    void zoomOut() { setZoom(zoom / 1.5f); }
    void resetZoom() {
        zoom = 1f;
        offsetX = 0f;
        offsetY = 0f;
        invalidate();
    }
    void rotateClockwise() { rotateBy(90); }
    void rotateCounterClockwise() { rotateBy(-90); }
    void resetView() {
        rotation = 0;
        resetZoom();
    }
    private void rotateBy(int delta) {
        rotation = (rotation + delta + 360) % 360;
        // Fit the newly rotated extents into the available viewport.
        resetZoom();
    }
    private void setZoom(float value) {
        zoom = Math.max(1f, Math.min(8f, value));
        if (zoom == 1f) { offsetX = 0; offsetY = 0; }
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (bitmap == null || bitmap.isRecycled() || getWidth() <= 0 || getHeight() <= 0) return;
        boolean quarterTurn = (rotation % 180) != 0;
        float visualWidth = quarterTurn ? bitmap.getHeight() : bitmap.getWidth();
        float visualHeight = quarterTurn ? bitmap.getWidth() : bitmap.getHeight();
        float fit = Math.min((float) getWidth() / visualWidth,
                (float) getHeight() / visualHeight);
        float scaledWidth = bitmap.getWidth() * fit * zoom;
        float scaledHeight = bitmap.getHeight() * fit * zoom;
        float rotatedWidth = visualWidth * fit * zoom;
        float rotatedHeight = visualHeight * fit * zoom;
        float maxX = Math.max(0f, (rotatedWidth - getWidth()) / 2f);
        float maxY = Math.max(0f, (rotatedHeight - getHeight()) / 2f);
        offsetX = Math.max(-maxX, Math.min(maxX, offsetX));
        offsetY = Math.max(-maxY, Math.min(maxY, offsetY));

        int saveCount = canvas.save();
        canvas.translate(getWidth() / 2f + offsetX, getHeight() / 2f + offsetY);
        canvas.rotate(rotation);
        canvas.drawBitmap(bitmap, null,
                new RectF(-scaledWidth / 2f, -scaledHeight / 2f,
                        scaledWidth / 2f, scaledHeight / 2f), paint);
        canvas.restoreToCount(saveCount);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        pinch.onTouchEvent(event);
        gesture.onTouchEvent(event);
        return true;
    }
}
