package com.privategallery.smb;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(13, 17, 26);
    private static final int PANEL = Color.rgb(25, 32, 45);
    private static final int ACCENT = Color.rgb(130, 174, 255);
    private static final int TEXT = Color.rgb(235, 242, 252);
    private static final int MUTED = Color.rgb(147, 161, 184);

    private final Handler ui = new Handler(Looper.getMainLooper());
    // Listing is a single metadata-only SMB operation. Photo decoding is isolated.
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService photoIo = Executors.newFixedThreadPool(2);
    private Future<?> photoTask;
    private final ArrayDeque<String> folderHistory = new ArrayDeque<>();

    private FrameLayout root;
    private LinearLayout connectionScreen;
    private LinearLayout browserScreen;
    private LinearLayout viewerScreen;
    private EditText smbPath, smbUser, smbPass, smbDomain;
    private CheckBox rememberConnection;
    private CredentialVault credentialVault;
    private Button connectButton;
    private TextView connectStatus, folderTitle, folderPath, folderStatus, photoTitle, photoCounter;
    private ListView fileList;
    private GalleryAdapter adapter;
    private ZoomImageView zoomView;
    private TextView viewerStatus;
    private SmbStore store;
    private String currentFolder;
    private final List<SmbStore.Entry> currentEntries = new ArrayList<>();
    private final List<SmbStore.Entry> photos = new ArrayList<>();
    private int photoIndex = 0;
    private int mode = 0; // 0 connection, 1 folders, 2 full-screen image
    private int connectionGeneration = 0;
    private int navigationGeneration = 0;
    private int photoGeneration = 0;
    private int sessionGeneration = 0;
    private boolean destroyed = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // Block Android screenshots, screen recording, and task snapshots.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                root.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        } else {
            root.setFitsSystemWindows(true);
        }
        makeConnectionScreen();
        makeBrowserScreen();
        makeViewerScreen();
        credentialVault = new CredentialVault(this);
        restoreSavedConnection();
        showMode(0);
    }

    private void makeConnectionScreen() {
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        LinearLayout content = column(22);
        content.setPadding(dp(24), dp(28), dp(24), dp(28));
        scroller.addView(content);
        connectionScreen = column(0);
        connectionScreen.addView(scroller, new LinearLayout.LayoutParams(-1, -1));
        root.addView(connectionScreen, new FrameLayout.LayoutParams(-1, -1));

        TextView mark = text("◈  SMB PRIVATE GALLERY", 13, ACCENT, true);
        content.addView(mark);
        space(content, 18);
        TextView headline = text("私密图片浏览器", 28, TEXT, true);
        content.addView(headline);
        space(content, 7);
        TextView subtitle = text("文件名列表 · 点击查看大图 · 无缩略图 · 不调用系统相册", 14, MUTED, false);
        content.addView(subtitle);
        space(content, 26);

        addLabel(content, "SMB 图片文件夹地址");
        smbPath = edit("smb://192.168.68.1/共享盘/图片/", false);
        smbPath.setSingleLine(true);
        content.addView(smbPath, new LinearLayout.LayoutParams(-1, dp(54)));
        space(content, 16);
        addLabel(content, "账号（匿名共享可留空）");
        smbUser = edit("SMB 用户名", false);
        content.addView(smbUser, new LinearLayout.LayoutParams(-1, dp(54)));
        space(content, 16);
        addLabel(content, "SMB 密码");
        smbPass = edit("SMB 密码", true);
        content.addView(smbPass, new LinearLayout.LayoutParams(-1, dp(54)));
        space(content, 16);
        addLabel(content, "域 / 工作组（可留空）");
        smbDomain = edit("WORKGROUP（可选）", false);
        content.addView(smbDomain, new LinearLayout.LayoutParams(-1, dp(54)));
        space(content, 13);

        rememberConnection = new CheckBox(this);
        rememberConnection.setText("记住 SMB 地址、用户名和密码（本机加密）");
        rememberConnection.setTextSize(13);
        rememberConnection.setTextColor(TEXT);
        rememberConnection.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        rememberConnection.setChecked(false);
        content.addView(rememberConnection, new LinearLayout.LayoutParams(-1, dp(48)));
        Button clearSaved = button("清除已保存的连接信息", false, () -> clearSavedConnection());
        content.addView(clearSaved, new LinearLayout.LayoutParams(-1, dp(46)));
        space(content, 18);

        connectButton = button("连接并浏览图片", true, () -> connect());
        content.addView(connectButton, new LinearLayout.LayoutParams(-1, dp(56)));
        space(content, 16);
        connectStatus = text("", 13, ACCENT, false);
        content.addView(connectStatus);
        space(content, 18);
        TextView notice = text(
                "隐私模式已开启\n" +
                "• 不申请相册与文件读写权限\n" +
                "• 不下载图片到手机存储\n" +
                "• 不生成缩略图、图片文件不建立磁盘缓存\n" +
                "• 勾选后将 SMB 连接信息加密保存到本机，可随时清除\n" +
                "• 切到后台清除内存中的图片缓存\n" +
                "• 禁止截图 / 录屏 / 最近任务预览\n\n" +
                "提示：请填写真实共享路径，例如 smb://192.168.1.1/USB/照片/。仅支持 SMB2/3。",
                13, MUTED, false);
        notice.setPadding(dp(16), dp(16), dp(16), dp(16));
        notice.setBackground(round(PANEL, 14));
        content.addView(notice, new LinearLayout.LayoutParams(-1, -2));
    }

    private void makeBrowserScreen() {
        browserScreen = column(0);
        browserScreen.setPadding(dp(15), dp(14), dp(15), dp(8));
        root.addView(browserScreen, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        Button back = button("‹", false, () -> backFromBrowser());
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(50), dp(50)));
        folderTitle = text("图片文件夹", 19, TEXT, true);
        folderTitle.setSingleLine(true);
        folderTitle.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, -2, 1f);
        titleLp.leftMargin = dp(9);
        toolbar.addView(folderTitle, titleLp);
        Button disconnect = button("断开", false, this::disconnect);
        toolbar.addView(disconnect, new LinearLayout.LayoutParams(dp(73), dp(45)));
        browserScreen.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(56)));
        folderPath = text("", 12, MUTED, false);
        folderPath.setSingleLine(true);
        folderPath.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        browserScreen.addView(folderPath);
        space(browserScreen, 14);
        folderStatus = text("", 12, ACCENT, false);
        browserScreen.addView(folderStatus);
        space(browserScreen, 8);
        fileList = new ListView(this);
        fileList.setClipToPadding(false);
        fileList.setDivider(null);
        fileList.setDividerHeight(dp(8));
        fileList.setPadding(dp(2), dp(4), dp(2), dp(15));
        fileList.setSelector(android.R.color.transparent);
        adapter = new GalleryAdapter();
        fileList.setAdapter(adapter);
        fileList.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= currentEntries.size()) return;
            SmbStore.Entry selected = currentEntries.get(position);
            if (selected.directory) {
                String previous = currentFolder;
                folderHistory.push(previous);
                navigate(selected.url, false);
            } else {
                photos.clear();
                for (SmbStore.Entry item : currentEntries) if (!item.directory) photos.add(item);
                for (int i = 0; i < photos.size(); ++i) {
                    if (photos.get(i).url.equals(selected.url)) { photoIndex = i; break; }
                }
                showMode(2);
                showPhoto();
            }
        });
        browserScreen.addView(fileList, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void makeViewerScreen() {
        viewerScreen = column(0);
        viewerScreen.setBackgroundColor(Color.BLACK);
        root.addView(viewerScreen, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(dp(12), dp(6), dp(12), dp(4));
        bar.setGravity(Gravity.CENTER_VERTICAL);
        Button back = button("‹", false, () -> leaveViewer());
        bar.addView(back, new LinearLayout.LayoutParams(dp(51), dp(46)));
        photoTitle = text("", 15, TEXT, true);
        photoTitle.setSingleLine(true);
        photoTitle.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, -2, 1f);
        titleLp.leftMargin = dp(10);
        bar.addView(photoTitle, titleLp);
        viewerScreen.addView(bar, new LinearLayout.LayoutParams(-1, dp(58)));
        FrameLayout photoArea = new FrameLayout(this);
        zoomView = new ZoomImageView(this);
        zoomView.setSwipeListener(direction -> changePhoto(direction));
        photoArea.addView(zoomView, new FrameLayout.LayoutParams(-1, -1));
        viewerStatus = text("", 14, TEXT, false);
        viewerStatus.setGravity(Gravity.CENTER);
        viewerStatus.setPadding(dp(18), dp(16), dp(18), dp(16));
        viewerStatus.setBackground(round(PANEL, 12));
        FrameLayout.LayoutParams statusLp = new FrameLayout.LayoutParams(
                dp(290), -2, Gravity.CENTER);
        photoArea.addView(viewerStatus, statusLp);
        viewerStatus.setVisibility(View.GONE);
        viewerScreen.addView(photoArea, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout tools = new LinearLayout(this);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        tools.setPadding(dp(10), dp(5), dp(10), dp(5));
        addViewerTool(tools, "缩小 −", () -> zoomView.zoomOut());
        addViewerTool(tools, "放大 +", () -> zoomView.zoomIn());
        addViewerTool(tools, "左转 ↶", () -> zoomView.rotateCounterClockwise());
        addViewerTool(tools, "右转 ↷", () -> zoomView.rotateClockwise());
        addViewerTool(tools, "恢复", () -> zoomView.resetView());
        viewerScreen.addView(tools, new LinearLayout.LayoutParams(-1, dp(55)));
        LinearLayout buttons = new LinearLayout(this);
        buttons.setPadding(dp(15), dp(12), dp(15), dp(18));
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        buttons.addView(button("上一张", false, () -> changePhoto(-1)),
                new LinearLayout.LayoutParams(0, dp(54), 1f));
        photoCounter = text("", 13, TEXT, false);
        photoCounter.setGravity(Gravity.CENTER);
        buttons.addView(photoCounter, new LinearLayout.LayoutParams(dp(92), dp(54)));
        buttons.addView(button("下一张", false, () -> changePhoto(+1)),
                new LinearLayout.LayoutParams(0, dp(54), 1f));
        viewerScreen.addView(buttons);
    }

    private void addViewerTool(LinearLayout toolbar, String label, Runnable action) {
        Button control = button(label, false, action);
        control.setTextSize(11);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(43), 1f);
        lp.leftMargin = dp(2);
        lp.rightMargin = dp(2);
        toolbar.addView(control, lp);
    }

    private void restoreSavedConnection() {
        if (!credentialVault.hasSaved()) return;
        try {
            CredentialVault.Profile profile = credentialVault.load();
            if (profile == null) return;
            smbPath.setText(profile.path);
            smbUser.setText(profile.user);
            smbPass.setText(profile.password);
            smbDomain.setText(profile.domain);
            rememberConnection.setChecked(true);
            connectStatus.setText("已恢复本机加密保存的 SMB 连接信息");
        } catch (Exception e) {
            rememberConnection.setChecked(false);
            connectStatus.setText("无法解密旧连接信息，请重新填写并保存，或点击清除。");
        }
    }

    private void clearSavedConnection() {
        credentialVault.clear();
        rememberConnection.setChecked(false);
        smbPath.setText("");
        smbUser.setText("");
        smbPass.setText("");
        smbDomain.setText("");
        connectStatus.setText("已清除本机保存的连接信息");
    }

    private void connect() {
        String path = smbPath.getText().toString().trim();
        String user = smbUser.getText().toString();
        String pass = smbPass.getText().toString();
        String domain = smbDomain.getText().toString().trim();
        if (path.isEmpty()) {
            connectStatus.setText("请先填写 SMB 共享地址。");
            return;
        }
        connectButton.setEnabled(false);
        connectStatus.setText("正在连接 SMB 服务器…");
        final int generation = ++connectionGeneration;
        io.execute(() -> {
            try {
                SmbStore candidate = new SmbStore(path, domain, user, pass);
                List<SmbStore.Entry> items = candidate.list(candidate.rootUrl);
                ui.post(() -> {
                    if (destroyed || generation != connectionGeneration) {
                        candidate.close();
                        return;
                    }
                    store = candidate;
                    currentFolder = candidate.rootUrl;
                    folderHistory.clear();
                    currentEntries.clear();
                    currentEntries.addAll(items);
                    ++sessionGeneration;
                    if (rememberConnection.isChecked()) {
                        try {
                            credentialVault.save(new CredentialVault.Profile(path, user, pass, domain));
                        } catch (Exception saveError) {
                            Toast.makeText(this,
                                    "SMB 已连接，但加密保存失败，请检查设备安全设置",
                                    Toast.LENGTH_LONG).show();
                        }
                    } else {
                        credentialVault.clear();
                        // Without user opt-in the credentials remain session-only.
                        smbPass.setText("");
                        smbUser.setText("");
                        smbDomain.setText("");
                        smbPath.setText("");
                    }
                    connectButton.setEnabled(true);
                    connectStatus.setText("");
                    updateBrowser();
                    showMode(1);
                });
            } catch (Exception error) {
                ui.post(() -> {
                    if (destroyed || generation != connectionGeneration) return;
                    connectButton.setEnabled(true);
                    connectStatus.setText("连接失败：" + message(error)
                            + "\n请检查 IP、共享名、账号和 SMB2/3 设置。");
                });
            }
        });
    }

    private void navigate(String target, boolean fromBack) {
        if (store == null) return;
        final int generation = ++navigationGeneration;
        final int session = sessionGeneration;
        folderStatus.setText("正在读取 SMB 文件夹…");
        SmbStore snapshot = store;
        io.execute(() -> {
            try {
                List<SmbStore.Entry> result = snapshot.list(target);
                ui.post(() -> {
                    if (destroyed || generation != navigationGeneration || session != sessionGeneration) return;
                    currentFolder = target;
                    currentEntries.clear();
                    currentEntries.addAll(result);
                    updateBrowser();
                });
            } catch (Exception e) {
                ui.post(() -> {
                    if (destroyed || generation != navigationGeneration || session != sessionGeneration) return;
                    // Undo a failed forward move, or restore back history.
                    if (fromBack) folderHistory.push(target);
                    else if (!folderHistory.isEmpty()) folderHistory.pop();
                    folderStatus.setText("文件夹读取失败：" + message(e));
                });
            }
        });
    }

    private void updateBrowser() {
        if (currentFolder == null) return;
        String value = currentFolder;
        if (value.endsWith("/")) value = value.substring(0, value.length() - 1);
        String[] sections = value.split("/");
        folderTitle.setText(sections.length == 0 ? "图片文件夹" : sections[sections.length - 1]);
        folderPath.setText(currentFolder);
        int folderCount = 0, imageCount = 0;
        for (SmbStore.Entry entry : currentEntries) {
            if (entry.directory) folderCount++;
            else imageCount++;
        }
        folderStatus.setText(folderCount + " 个文件夹  ·  " + imageCount + " 张图片");
        adapter.notifyDataSetChanged();
        fileList.setSelection(0);
    }

    private void backFromBrowser() {
        if (!folderHistory.isEmpty()) navigate(folderHistory.pop(), true);
        else disconnect();
    }

    private void showPhoto() {
        if (store == null || photos.isEmpty() || mode != 2) return;
        final int generation = ++photoGeneration;
        final int session = sessionGeneration;
        SmbStore.Entry entry = photos.get(photoIndex);
        photoTitle.setText(entry.name);
        photoCounter.setText((photoIndex + 1) + " / " + photos.size());
        if (photoTask != null) photoTask.cancel(true);
        zoomView.setBitmap(null);
        viewerStatus.setText("正在从 SMB 读取图片…\n直接加载当前图片，不生成缩略图");
        viewerStatus.setVisibility(View.VISIBLE);
        SmbStore snapshot = store;
        photoTask = photoIo.submit(() -> {
            Bitmap bmp = null;
            String error = null;
            try { bmp = snapshot.decode(entry.url, 4096, 4096); }
            catch (Exception e) { error = message(e); }
            final Bitmap result = bmp;
            final String detail = error;
            ui.post(() -> {
                if (destroyed || generation != photoGeneration || session != sessionGeneration || mode != 2) {
                    if (result != null) result.recycle();
                    return;
                }
                if (result != null) {
                    zoomView.setBitmap(result);
                    viewerStatus.setVisibility(View.GONE);
                } else {
                    viewerStatus.setText("图片无法打开\n" + detail
                            + "\n\n请检查 SMB 网络，或尝试其他 JPG 图片");
                    viewerStatus.setVisibility(View.VISIBLE);
                }
            });
        });
    }

    private void changePhoto(int direction) {
        if (photos.isEmpty()) return;
        photoIndex = (photoIndex + direction + photos.size()) % photos.size();
        showPhoto();
    }

    private void leaveViewer() {
        ++photoGeneration;
        if (photoTask != null) photoTask.cancel(true);
        zoomView.setBitmap(null);
        viewerStatus.setVisibility(View.GONE);
        photos.clear();
        showMode(1);
    }

    private void disconnect() {
        ++connectionGeneration;
        ++navigationGeneration;
        ++photoGeneration;
        ++sessionGeneration;
        if (photoTask != null) photoTask.cancel(true);
        SmbStore previousStore = store;
        store = null;
        if (previousStore != null) previousStore.close();
        currentFolder = null;
        folderHistory.clear();
        photos.clear();
        currentEntries.clear();
        if (zoomView != null) zoomView.setBitmap(null);
        if (viewerStatus != null) viewerStatus.setVisibility(View.GONE);
        if (adapter != null) adapter.notifyDataSetChanged();
        connectButton.setEnabled(true);
        connectStatus.setText("");
        showMode(0);
    }

    private void showMode(int requested) {
        mode = requested;
        connectionScreen.setVisibility(mode == 0 ? View.VISIBLE : View.GONE);
        browserScreen.setVisibility(mode == 1 ? View.VISIBLE : View.GONE);
        viewerScreen.setVisibility(mode == 2 ? View.VISIBLE : View.GONE);
    }

    @Override public void onBackPressed() {
        if (mode == 2) leaveViewer();
        else if (mode == 1) backFromBrowser();
        else super.onBackPressed();
    }

    @Override protected void onStop() {
        super.onStop();
        // Clear decoded images when no longer visible; do not write state to a Bundle.
        ++photoGeneration;
        ++sessionGeneration;
        if (photoTask != null) photoTask.cancel(true);
        if (zoomView != null) zoomView.setBitmap(null);
        if (viewerStatus != null) viewerStatus.setVisibility(View.GONE);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    @Override protected void onStart() {
        super.onStart();
        if (mode == 2 && store != null && !photos.isEmpty()) showPhoto();
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // The filename list is responsive without column recalculation.
    }

    @Override protected void onDestroy() {
        destroyed = true;
        disconnect();
        io.shutdownNow();
        photoIo.shutdownNow();
        super.onDestroy();
    }

    /** Filename-only adapter: never contacts SMB to generate image previews. */
    private final class GalleryAdapter extends BaseAdapter {
        @Override public int getCount() { return currentEntries.size(); }
        @Override public Object getItem(int position) { return currentEntries.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public View getView(int position, View convertView, ViewGroup parent) {
            SmbStore.Entry entry = currentEntries.get(position);
            FileRow row;
            if (convertView != null && convertView.getTag() instanceof FileRow) {
                row = (FileRow) convertView.getTag();
            } else {
                row = new FileRow();
                LinearLayout item = new LinearLayout(MainActivity.this);
                item.setOrientation(LinearLayout.HORIZONTAL);
                item.setGravity(Gravity.CENTER_VERTICAL);
                item.setPadding(dp(14), dp(12), dp(14), dp(12));
                item.setMinimumHeight(dp(68));
                item.setBackground(round(PANEL, 12));
                row.symbol = text("", 27, ACCENT, true);
                row.symbol.setGravity(Gravity.CENTER);
                item.addView(row.symbol, new LinearLayout.LayoutParams(dp(45), dp(45)));
                LinearLayout details = column(0);
                details.setPadding(dp(10), 0, 0, 0);
                row.title = text("", 15, TEXT, true);
                row.title.setSingleLine(true);
                row.title.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                details.addView(row.title);
                row.subtitle = text("", 12, MUTED, false);
                details.addView(row.subtitle);
                item.addView(details, new LinearLayout.LayoutParams(0, -2, 1f));
                item.setTag(row);
                row.root = item;
            }
            row.symbol.setText(entry.directory ? "▣" : "▧");
            row.title.setText(entry.name);
            row.subtitle.setText(entry.directory ? "文件夹 · 点击进入" : "图片 · 点击查看原始文件");
            return row.root;
        }
    }

    private static final class FileRow {
        LinearLayout root;
        TextView symbol, title, subtitle;
    }

    private static String message(Exception e) {
        if (e.getMessage() == null || e.getMessage().trim().isEmpty()) return e.getClass().getSimpleName();
        String s = e.getMessage();
        // Do not show lengthy diagnostic messages, stack traces, or URLs.
        if (s.length() > 110) s = s.substring(0, 110);
        return s;
    }

    private EditText edit(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setHint(hint);
        e.setPadding(dp(14), 0, dp(14), 0);
        e.setBackground(round(PANEL, 11));
        e.setInputType(password
                ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setImeOptions(EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING | EditorInfo.IME_ACTION_NEXT);
        e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        e.setSaveEnabled(false);
        return e;
    }

    private void addLabel(LinearLayout parent, String str) {
        TextView label = text(str, 13, MUTED, false);
        parent.addView(label);
        space(parent, 8);
    }

    private Button button(String label, boolean primary, Runnable action) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setTextSize(14);
        btn.setAllCaps(false);
        btn.setTextColor(primary ? BG : TEXT);
        btn.setBackground(round(primary ? ACCENT : PANEL, 12));
        btn.setPadding(dp(6), 0, dp(6), 0);
        btn.setOnClickListener(v -> action.run());
        return btn;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setLineSpacing(dp(2), 1f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column(int margin) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        if (margin > 0) l.setPadding(dp(margin), dp(margin), dp(margin), dp(margin));
        return l;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private void space(LinearLayout parent, int height) {
        parent.addView(new View(this), new LinearLayout.LayoutParams(1, dp(height)));
    }

    private int dp(float amount) {
        return Math.round(amount * getResources().getDisplayMetrics().density);
    }
}
