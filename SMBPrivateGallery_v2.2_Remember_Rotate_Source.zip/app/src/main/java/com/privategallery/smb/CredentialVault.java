package com.privategallery.smb;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * User-opt-in credential persistence. Everything (including server address)
 * is encrypted with an app-owned Android Keystore AES-GCM key. No plain-text
 * credential keys are stored in SharedPreferences or backup.
 */
final class CredentialVault {
    private static final String PREFS = "secure_smb_connection_v1";
    private static final String ENTRY = "encrypted_profile";
    private static final String KEY_ALIAS = "SMBPrivateGallery.connection.aes.v1";
    private static final String KEYSTORE = "AndroidKeyStore";

    static final class Profile {
        final String path, user, password, domain;
        Profile(String path, String user, String password, String domain) {
            this.path = path;
            this.user = user;
            this.password = password;
            this.domain = domain;
        }
    }

    private final Context context;

    CredentialVault(Context context) {
        this.context = context.getApplicationContext();
    }

    boolean hasSaved() {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(ENTRY);
    }

    void save(Profile profile) throws Exception {
        JSONObject data = new JSONObject();
        data.put("path", profile.path);
        data.put("user", profile.user);
        data.put("password", profile.password);
        data.put("domain", profile.domain);
        byte[] clear = data.toString().getBytes(StandardCharsets.UTF_8);
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key());
            String encodedIv = Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP);
            String encodedData = Base64.encodeToString(cipher.doFinal(clear), Base64.NO_WRAP);
            boolean persisted = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(ENTRY, "v1:" + encodedIv + ":" + encodedData).commit();
            if (!persisted) throw new IllegalStateException("无法写入加密连接信息");
        } finally {
            Arrays.fill(clear, (byte) 0);
        }
    }

    Profile load() throws Exception {
        String stored = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(ENTRY, null);
        if (stored == null) return null;
        String[] parts = stored.split(":", 3);
        if (parts.length != 3 || !"v1".equals(parts[0])) {
            throw new IllegalStateException("保存的连接资料格式不正确");
        }
        byte[] iv = Base64.decode(parts[1], Base64.NO_WRAP);
        byte[] encrypted = Base64.decode(parts[2], Base64.NO_WRAP);
        if (iv.length != 12) throw new IllegalStateException("连接资料验证失败");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
        byte[] clear = cipher.doFinal(encrypted);
        try {
            JSONObject data = new JSONObject(new String(clear, StandardCharsets.UTF_8));
            return new Profile(data.optString("path"), data.optString("user"),
                    data.optString("password"), data.optString("domain"));
        } finally {
            Arrays.fill(clear, (byte) 0);
        }
    }

    void clear() {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(ENTRY).commit();
        try {
            KeyStore store = KeyStore.getInstance(KEYSTORE);
            store.load(null);
            if (store.containsAlias(KEY_ALIAS)) store.deleteEntry(KEY_ALIAS);
        } catch (Exception ignored) {
            // Prefs are wiped regardless of whether the old keystore entry exists.
        }
    }

    private static SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance(KEYSTORE);
        store.load(null);
        KeyStore.Entry entry = store.getEntry(KEY_ALIAS, null);
        if (entry instanceof KeyStore.SecretKeyEntry) {
            return ((KeyStore.SecretKeyEntry) entry).getSecretKey();
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .setKeySize(256)
                .build());
        return generator.generateKey();
    }
}
