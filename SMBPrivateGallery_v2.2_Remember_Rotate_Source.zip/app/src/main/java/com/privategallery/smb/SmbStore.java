package com.privategallery.smb;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import jcifs.CIFSContext;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import jcifs.smb.SmbFile;

/**
 * SMB2/3 reader. Image bytes exist only temporarily in RAM: never written to
 * Android media storage, disk cache, or a system image-viewer intent.
 */
final class SmbStore {
    // The 7000x4000 / ~8 MB target fits easily. Refuse unusually huge compressed
    // files rather than allocating an unbounded buffer on the phone.
    private static final int MAX_COMPRESSED_BYTES = 40 * 1024 * 1024;
    private static final int NETWORK_BUFFER_BYTES = 64 * 1024;

    static final class Entry {
        final String name;
        final String url;
        final boolean directory;
        Entry(String name, String url, boolean directory) {
            this.name = name;
            this.url = url;
            this.directory = directory;
        }
    }

    private final CIFSContext context;
    final String rootUrl;

    SmbStore(String rawUrl, String domain, String username, String password) throws Exception {
        String path = rawUrl.trim();
        if (!path.startsWith("smb://")) path = "smb://" + path;
        if (path.contains("?") || path.contains("#") || path.contains("@")) {
            throw new IllegalArgumentException("请只填写 SMB 地址，勿在地址中加入密码或特殊参数");
        }
        String remainder = path.substring("smb://".length());
        if (remainder.indexOf('/') <= 0 || remainder.indexOf('/') == remainder.length() - 1) {
            if (remainder.indexOf('/') < 0 || remainder.substring(remainder.indexOf('/') + 1).trim().isEmpty()) {
                throw new IllegalArgumentException("地址格式：smb://服务器IP/共享名称/图片文件夹/");
            }
        }
        if (!path.endsWith("/")) path += "/";
        this.rootUrl = path;

        Properties properties = new Properties();
        properties.setProperty("jcifs.smb.client.minVersion", "SMB202");
        properties.setProperty("jcifs.smb.client.maxVersion", "SMB300");
        // A remote 8 MB JPEG may need longer than 15 seconds on busy Wi-Fi.
        properties.setProperty("jcifs.smb.client.connTimeout", "12000");
        properties.setProperty("jcifs.smb.client.responseTimeout", "45000");
        properties.setProperty("jcifs.smb.client.soTimeout", "45000");
        NtlmPasswordAuthenticator credentials;
        if (username.isEmpty() && password.isEmpty()) {
            credentials = new NtlmPasswordAuthenticator();
        } else if ("guest".equalsIgnoreCase(username) && password.isEmpty()) {
            credentials = new NtlmPasswordAuthenticator(
                    NtlmPasswordAuthenticator.AuthenticationType.GUEST);
        } else {
            credentials = new NtlmPasswordAuthenticator(domain, username, password);
        }
        context = new BaseContext(new PropertyConfiguration(properties))
                .withCredentials(credentials);
    }

    List<Entry> list(String folderUrl) throws IOException {
        List<Entry> folders = new ArrayList<>();
        List<Entry> images = new ArrayList<>();
        try (SmbFile folder = new SmbFile(folderUrl, context)) {
            if (!folder.exists() || !folder.isDirectory()) {
                throw new IOException("找不到共享目录，或当前账号没有读取权限");
            }
            SmbFile[] files = folder.listFiles();
            if (files == null) return folders;
            for (SmbFile item : files) {
                try (SmbFile current = item) {
                    String name = current.getName();
                    if (name == null || name.equals(".") || name.equals("..")) continue;
                    boolean isDir = current.isDirectory();
                    if (isDir) {
                        folders.add(new Entry(trimSlash(name), current.getPath(), true));
                    } else if (isImage(name)) {
                        images.add(new Entry(name, current.getPath(), false));
                    }
                } catch (IOException ignored) {
                    // An unreadable item must not hide the rest of the directory.
                }
            }
        }
        Comparator<Entry> byName = (a, b) ->
                String.CASE_INSENSITIVE_ORDER.compare(a.name, b.name);
        folders.sort(byName);
        images.sort(byName);
        folders.addAll(images);
        return folders;
    }

    /**
     * Read a file once over SMB, then perform bounds decoding and sampled
     * bitmap decoding from the same transient byte array. No disk is used.
     */
    Bitmap decode(String imageUrl, int maxWidth, int maxHeight) throws IOException {
        if (maxWidth <= 0 || maxHeight <= 0) throw new IllegalArgumentException("Invalid size");
        byte[] compressed = readImageBytes(imageUrl);
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(compressed, 0, compressed.length, bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                throw new IOException("无法识别图片编码；请检查格式是否受 Android 支持");
            }
            int sample = 1;
            // Unlike the old two-times-size rule, strictly cap decoded dimensions
            // to the requested display size. For 7000x4000 at 4000x3000 => 2.
            while (bounds.outWidth / sample > maxWidth ||
                   bounds.outHeight / sample > maxHeight) {
                if (sample >= 1 << 20) break;
                sample *= 2;
            }
            boolean jpeg = isJpeg(imageUrl) || "image/jpeg".equalsIgnoreCase(bounds.outMimeType);
            // Most photos are opaque JPEGs: RGB_565 cuts bitmap RAM in half.
            // Preserve alpha for PNG / WebP / other image formats.
            for (int attempt = 0; attempt < 4; attempt++) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = sample;
                options.inScaled = false;
                options.inPreferredConfig = jpeg ? Bitmap.Config.RGB_565 : Bitmap.Config.ARGB_8888;
                options.inDither = true;
                try {
                    Bitmap result = BitmapFactory.decodeByteArray(
                            compressed, 0, compressed.length, options);
                    if (result != null) return result;
                    throw new IOException("图片解码失败；可能不支持当前格式或文件已损坏");
                } catch (OutOfMemoryError oom) {
                    // Degrade resolution instead of crashing the Activity.
                    sample *= 2;
                    if (attempt == 3) {
                        throw new IOException("图片过大，降低分辨率后仍然内存不足", oom);
                    }
                }
            }
            throw new IOException("图片解码失败");
        } finally {
            // Best-effort erasure of compressed image bytes from the Java heap.
            Arrays.fill(compressed, (byte) 0);
        }
    }

    private byte[] readImageBytes(String imageUrl) throws IOException {
        try (SmbFile file = new SmbFile(imageUrl, context)) {
            long reportedSize = file.length();
            if (reportedSize > MAX_COMPRESSED_BYTES) {
                throw new IOException("压缩图片超过 40 MB 安全读取上限");
            }
            int initialCapacity = (int) Math.min(Math.max(reportedSize, 64 * 1024), 8 * 1024 * 1024);
            try (InputStream input = new BufferedInputStream(file.getInputStream(), NETWORK_BUFFER_BYTES);
                 ByteArrayOutputStream output = new ByteArrayOutputStream(initialCapacity)) {
                byte[] transfer = new byte[NETWORK_BUFFER_BYTES];
                int count;
                int total = 0;
                while ((count = input.read(transfer)) != -1) {
                    if (Thread.currentThread().isInterrupted()) {
                        throw new IOException("图片读取已取消");
                    }
                    if (count > MAX_COMPRESSED_BYTES - total) {
                        throw new IOException("压缩图片超过 40 MB 安全读取上限");
                    }
                    output.write(transfer, 0, count);
                    total += count;
                }
                if (total == 0) throw new IOException("SMB 返回空图片数据");
                Arrays.fill(transfer, (byte) 0);
                return output.toByteArray();
            }
        } catch (OutOfMemoryError oom) {
            throw new IOException("读取图片时内存不足，请关闭其他应用后重试", oom);
        }
    }

    void close() {
        try { context.close(); }
        catch (Exception ignored) { /* Credentials are no longer used. */ }
    }

    static boolean isImage(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg") ||
               lower.endsWith(".png") || lower.endsWith(".webp") ||
               lower.endsWith(".bmp") || lower.endsWith(".gif") ||
               lower.endsWith(".heic") || lower.endsWith(".heif") ||
               lower.endsWith(".avif");
    }

    private static boolean isJpeg(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg");
    }

    private static String trimSlash(String s) {
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
}
