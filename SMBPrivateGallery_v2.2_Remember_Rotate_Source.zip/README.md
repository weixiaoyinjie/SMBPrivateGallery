# SMB Private Gallery v2.2 — 无缩略图 · 加密保存 SMB · 大图旋转与放大

在 Android 手机内直接通过 SMB2/3 查看共享硬盘里的图片，不调用系统相册。基于你已测试过的 v2.1 修改。

## v2.2 新增

1. **可保存连接信息**：在连接页勾选“记住 SMB 地址、用户名和密码（本机加密）”，成功连接后将地址、用户名、密码和工作组一并使用 Android Keystore AES-256-GCM 加密后保存到应用私有 SharedPreferences。下次启动自动填入，不会自动连接。
2. **可手动清除**：在连接页点击“清除已保存的连接信息”，同时清空表单、加密资料并尽力删除 Keystore 密钥。取消勾选并成功连接时，也会删除之前保存的资料。
3. **大图控制**：全屏页面新增 **缩小 −、放大 +、左转 ↶ 90°、右转 ↷ 90°、恢复** 按钮。保留双指捏合、双击放大、放大后拖动、上一张/下一张及左右滑动切换。旋转只改变屏幕显示，不修改 SMB 原文件。
4. **细节放大**：7000×4000 的 JPEG 采用适合约 4096×4096 解码上限的采样尺寸；JPEG 使用 RGB_565 节省内存，OOM 时自动降采样。最大 8 倍显示缩放不代表能够无损还原全部原像素。

## 保留的功能

- **完全没有缩略图**：文件夹只列出文件夹名和图片文件名，不会预加载邻近图片。
- SMB 图片下载后临时存放在内存中解码，不主动写入图片文件或磁盘缓存。
- 不使用手机相册、不申请相册或存储权限。
- 关闭/后台时移除显示的解码 Bitmap，防止常规截图、录屏和最近任务图片预览。
- 兼容现有 SMB2/3 访问逻辑；原有连接与列表操作不变。

## 已有仓库的编译方式

仓库：`https://github.com/weixiaoyinjie/SMBPrivateGallery`

1. 将 **SMBPrivateGallery_v2.2_Remember_Rotate_Source.zip** 原样上传到仓库根目录（不要上传到 `app/`）。旧 ZIP 可以保留。
2. 用另附的 **SMBPrivateGallery_v2.2_build.yml** 完整替换仓库 `.github/workflows/android-build.yml` 内容。
3. Actions → Build SMB Private Gallery APK → Run workflow，成功后下载 Artifact **SMBPrivateGallery-v2.2-debug-apk**，解压得到 `app-debug.apk`。
4. 如果安装提示应用签名冲突，请先卸载旧版再安装；卸载会清空之前版本的本地数据。

## 隐私边界

启用“记住连接信息”后，App **会有意在本机保存加密凭证**，因此它不再属于完全不保存任何设置的模式。解密凭证的 Android Keystore 密钥通常不能导出；仍无法保证操作系统、SMB 服务器、路由器和输入法完全没有其他访问记录。SMB 网络传输是否加密取决于协议协商和服务端配置。应用的 `allowBackup=false` 以及备份/设备迁移排除规则减少数据转移风险。

## 测试状态

已检查源码文件、Java 解析、Android Manifest XML 和 ZIP 结构；当前环境没有 Android SDK，**未在此运行 Gradle 构建或安装 APK 进行真机验证**。
