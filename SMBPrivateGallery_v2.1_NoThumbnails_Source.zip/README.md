# SMB Private Gallery v2.1 — 无缩略图的大图浏览版

独立 Android 手机 App。连接 SMB2/3 共享文件夹，只列出文件夹名称与图片文件名，点击后在 App 内全屏查看。**完全不生成缩略图，也不会预加载其他图片**。

## 核心功能

- 文件夹列表、图片文件名列表（列目录时不下载图片，速度更快）
- 点图片才从 SMB 读取当前图片；上一张/下一张、左右滑动、双指缩放、双击放大
- 优化 7000×4000、约 8 MB 的 JPG：一次 SMB 读取压缩文件到临时内存，先取得尺寸，再按显示需要解码；JPG 优先用 RGB_565，内存不足进一步降采样
- 支持 JPG/JPEG、PNG、WebP、BMP、GIF 静态首帧；HEIC/HEIF、AVIF 取决于系统解码器
- 不调用手机相册和文件管理器；不申请相册/存储权限，图片不保存到手机磁盘，不保存历史与 SMB 密码
- 退出或切到后台清空图片显示内存，禁止常规截图、录屏和最近任务缩略预览（FLAG_SECURE）

## 编译说明（适用于你当前的 GitHub 仓库）

你的仓库是 `weixiaoyinjie/SMBPrivateGallery`，之前源码 ZIP 被作为文件上传到仓库根目录。**GitHub Actions 不会自动解压 ZIP**。所以本次使用单个 ZIP + 自动解压的构建脚本。

1. 将 `SMBPrivateGallery_v2.1_NoThumbnails_Source.zip` 上传到仓库根目录，保持原文件名；无需解压。
2. 将仓库文件 `.github/workflows/android-build.yml` 替换为附件 `SMBPrivateGallery_v2.1_build.yml` 中的内容。
3. GitHub → Actions → Build SMB Private Gallery APK → Run workflow；构建成功后下载 artifact `SMBPrivateGallery-v2.1-debug-apk` 并解压获得 APK。

**本环境没有 Android SDK，无法在此进行 APK 的 Gradle 构建或真机连接 SMB 测试。** 只进行了静态结构与打包验证。

## 隐私边界

不主动写图片到手机文件存储不等于在所有设备上绝对无痕。SMB 服务器、网络设备、Android 系统诊断及输入法等仍可能记录活动。SMB 网络链路的加密状态也取决于服务器与协议协商。

## 已知限制

- 显示的大图是按设备需要降采样的显示版本，不保留 7000×4000 的原始逐像素放大细节；SMB 原文件不修改。
- 图片首次显示受 SMB 传输速度影响；默认单张压缩文件最大支持 40 MB。
- 当前版本不支持 SMB1；会尽可能协商 SMB2 / SMB3。
- 连接信息不会持久保存，下一次打开需要重新输入。
