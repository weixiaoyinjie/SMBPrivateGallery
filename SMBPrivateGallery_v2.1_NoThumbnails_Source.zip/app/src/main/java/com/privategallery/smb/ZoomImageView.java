package com.privategallery.smb;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/** Gesture handling is entirely in-app; images are never shared with system viewers. */
final class ZoomImageView extends View {
    interface SwipeListener { void onSwipe(int direction); }
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final ScaleGestureDetector pinch;
    private final GestureDetector gesture;
    private SwipeListener swipeListener;
    private Bitmap bitmap;
    private float zoom = 1f;
    private float offsetX = 0f, offsetY = 0f;

    ZoomImageView(Context context) {
        super(context);
        setBackgroundColor(Color.BLACK);
        pinch = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                float old = zoom;
                zoom = Math.max(1f, Math.min(5f, zoom * detector.getScaleFactor()));
                if (old != zoom) invalidate();
                return true;
            }
        });
        gesture = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                zoom = zoom > 1.05f ? 1f : 2.5f;
                offsetX = 0f;
                offsetY = 0f;
                invalidate();
                return true;
            }
            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2,
                                              float distanceX, float distanceY) {
                if (zoom > 1.05f && !pinch.isInProgress()) {
                    offsetX -= distanceX;
                    offsetY -= distanceY;
                    invalidate();
                    return true;
                }
                return false;
            }
            @Override public boolean onFling(MotionEvent e1, MotionEvent e2,
                                             float velocityX, float velocityY) {
                if (zoom > 1.05f || e1 == null || e2 == null || swipeListener == null) return false;
                float dx = e2.getX() - e1.getX();
                if (Math.abs(dx) > 65 * getResources().getDisplayMetrics().density &&
                    Math.abs(velocityX) > 300 && Math.abs(dx) > Math.abs(e2.getY() - e1.getY())) {
                    swipeListener.onSwipe(dx < 0 ? +1 : -1);
                    return true;
                }
                return false;
            }
        });
    }

    void setSwipeListener(SwipeListener listener) { swipeListener = listener; }
    void setBitmap(Bitmap value) {
        Bitmap old = bitmap;
        bitmap = value;
        // Bitmap is exclusively owned by this viewer (thumbnails use a separate
        // memory-only cache). Explicitly release the old pixel buffer.
        if (old != null && old != value && !old.isRecycled()) old.recycle();
        zoom = 1f;
        offsetX = 0f;
        offsetY = 0f;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (bitmap == null || bitmap.isRecycled()) return;
        float fit = Math.min((float)getWidth() / bitmap.getWidth(),
                             (float)getHeight() / bitmap.getHeight());
        float w = bitmap.getWidth() * fit * zoom;
        float h = bitmap.getHeight() * fit * zoom;
        float maxX = Math.max(0f, (w - getWidth()) / 2f);
        float maxY = Math.max(0f, (h - getHeight()) / 2f);
        offsetX = Math.max(-maxX, Math.min(maxX, offsetX));
        offsetY = Math.max(-maxY, Math.min(maxY, offsetY));
        float left = (getWidth() - w) / 2f + offsetX;
        float top = (getHeight() - h) / 2f + offsetY;
        canvas.drawBitmap(bitmap, null,
                new android.graphics.RectF(left, top, left + w, top + h), paint);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        pinch.onTouchEvent(event);
        gesture.onTouchEvent(event);
        return true;
    }
}
