package com.privategallery.smb;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import jcifs.CIFSContext;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import jcifs.smb.SmbFile;

/** In-memory SMB2/3 reader. Never uses local files, MediaStore, or disk caches. */
final class SmbStore {
    static final class Entry {
        final String name;
        final String url;
        final boolean directory;
        Entry(String name, String url, boolean directory) {
            this.name = name;
            this.url = url;
            this.directory = directory;
        }
    }

    private final CIFSContext context;
    final String rootUrl;

    SmbStore(String rawUrl, String domain, String username, String password) throws Exception {
        String path = rawUrl.trim();
        if (!path.startsWith("smb://")) path = "smb://" + path;
        if (path.contains("?") || path.contains("#") || path.contains("@")) {
            throw new IllegalArgumentException("请只填写 SMB 地址，勿在地址中加入密码或特殊参数");
        }
        // Must contain server and share. Browsing workgroups is not supported.
        String remainder = path.substring("smb://".length());
        if (remainder.indexOf('/') <= 0 || remainder.indexOf('/') == remainder.length() - 1) {
            // smb://server/share is fine; smb://server/ is not.
            if (remainder.indexOf('/') < 0 || remainder.substring(remainder.indexOf('/') + 1).trim().isEmpty()) {
                throw new IllegalArgumentException("地址格式：smb://服务器IP/共享名称/图片文件夹/");
            }
        }
        if (!path.endsWith("/")) path += "/";
        this.rootUrl = path;

        Properties properties = new Properties();
        // Never negotiate SMB1. SMB2.02 through SMB3.0 are supported by jcifs-ng.
        properties.setProperty("jcifs.smb.client.minVersion", "SMB202");
        properties.setProperty("jcifs.smb.client.maxVersion", "SMB300");
        properties.setProperty("jcifs.smb.client.connTimeout", "10000");
        properties.setProperty("jcifs.smb.client.responseTimeout", "15000");
        properties.setProperty("jcifs.smb.client.soTimeout", "15000");
        // Only an in-memory CIFSContext holds these credentials.
        NtlmPasswordAuthenticator credentials;
        if (username.isEmpty() && password.isEmpty()) {
            credentials = new NtlmPasswordAuthenticator(); // True anonymous access.
        } else if ("guest".equalsIgnoreCase(username) && password.isEmpty()) {
            credentials = new NtlmPasswordAuthenticator(
                    NtlmPasswordAuthenticator.AuthenticationType.GUEST);
        } else {
            credentials = new NtlmPasswordAuthenticator(domain, username, password);
        }
        context = new BaseContext(new PropertyConfiguration(properties))
                .withCredentials(credentials);
    }

    List<Entry> list(String folderUrl) throws IOException {
        List<Entry> folders = new ArrayList<>();
        List<Entry> images = new ArrayList<>();
        try (SmbFile folder = new SmbFile(folderUrl, context)) {
            if (!folder.exists() || !folder.isDirectory()) {
                throw new IOException("找不到共享目录，或当前账号没有读取权限");
            }
            SmbFile[] files = folder.listFiles();
            if (files == null) return folders;
            for (SmbFile item : files) {
                try (SmbFile current = item) {
                    String name = current.getName();
                    if (name == null || name.equals(".") || name.equals("..")) continue;
                    boolean isDir = current.isDirectory();
                    if (isDir) {
                        folders.add(new Entry(trimSlash(name), current.getPath(), true));
                    } else if (isImage(name)) {
                        images.add(new Entry(name, current.getPath(), false));
                    }
                } catch (IOException ignored) {
                    // One unreadable item must not hide the whole directory.
                }
            }
        }
        Comparator<Entry> byName = (a,b) -> String.CASE_INSENSITIVE_ORDER.compare(a.name,b.name);
        folders.sort(byName);
        images.sort(byName);
        folders.addAll(images);
        return folders;
    }

    Bitmap decode(String imageUrl, int maxWidth, int maxHeight) throws IOException {
        if (maxWidth <= 0 || maxHeight <= 0) throw new IllegalArgumentException("Invalid size");
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (SmbFile file = new SmbFile(imageUrl, context);
             InputStream stream = file.getInputStream()) {
            BitmapFactory.decodeStream(stream, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw new IOException("无法识别图片格式");
        }
        int sample = 1;
        while (bounds.outWidth / sample > maxWidth * 2L ||
               bounds.outHeight / sample > maxHeight * 2L) {
            sample *= 2;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        try (SmbFile file = new SmbFile(imageUrl, context);
             InputStream stream = file.getInputStream()) {
            Bitmap bmp = BitmapFactory.decodeStream(stream, null, options);
            if (bmp == null) throw new IOException("图片读取失败或格式不受支持");
            return bmp;
        } catch (OutOfMemoryError oom) {
            throw new IOException("图片太大，设备内存不足", oom);
        }
    }

    void close() {
        try { context.close(); }
        catch (Exception ignored) { /* Credentials and transport are no longer used. */ }
    }

    static boolean isImage(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg") ||
               lower.endsWith(".png") || lower.endsWith(".webp") ||
               lower.endsWith(".bmp") || lower.endsWith(".gif") ||
               lower.endsWith(".heic") || lower.endsWith(".heif") ||
               lower.endsWith(".avif");
    }

    private static String trimSlash(String s) {
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
}
