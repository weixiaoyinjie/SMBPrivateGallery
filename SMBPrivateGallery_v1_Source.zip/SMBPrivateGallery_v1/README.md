# SMB 私密相册 · SMB Private Gallery v1.0

**Android 手机端独立图片浏览器**。直接从局域网 SMB2/3 共享读取文件夹和图片，图片只在 App 内显示，不启动系统相册、不调用其他图片查看器、不导入 MediaStore。

## 功能

- 手动输入 `smb://服务器IP/共享名/图片文件夹/`，支持 SMB 账号、密码、域/工作组（空账号用于匿名共享）
- 目录浏览、图片缩略图网格、全屏、上一张/下一张、左右滑动、双指缩放、双击放大
- 只读访问，不会修改、复制、上传或删除 SMB 图片
- 缩略图仅使用 **12 MiB 内存 LRU 缓存**，不建立磁盘缓存，不保存“最近查看”记录
- 不要求相册权限、存储权限；不保存 SMB 凭证；切后台清除解码图片内存缓存
- `FLAG_SECURE` 防止常规截图、系统录屏与最近任务界面预览；`excludeFromRecents` 不进入最近任务列表
- 禁止 Android Auto Backup；无广告、无统计 SDK

## 使用方法

1. 确保手机和 SMB 设备在同一局域网（或者可路由互通）。
2. 在 SMB 设备开启 **SMB2/SMB3**，确认账号有读取权限。旧路由器如只提供 SMB1，需要升级路由器/共享配置，本 App 为安全原因不启用 SMB1。
3. 打开 App 输入真实地址，例如 `smb://192.168.68.1/USB/照片/`。特别注意：`USB` 是示例名称，不是固定名称。
4. 输入用户名及密码（共享允许匿名访问时可留空），点 **连接并浏览图片**。
5. 点击图片全屏，左右滑动或点下一张/上一张，双指缩放或双击放大；返回上级、点断开结束会话。

## GitHub 自动生成 APK（无需本地 Android Studio）

1. 打开 https://github.com/new ，建一个仓库（例：`SMBPrivateGallery`）。
2. 将本 ZIP 解压后，**上传解压出来的所有文件和 `.github/workflows/android-build.yml`** 到仓库根目录。建议使用电脑或支持上传文件夹的 Git 客户端，确保隐藏的 `.github` 文件夹上传成功。
3. 进入仓库 **Actions → Build SMB Private Gallery APK → Run workflow**；推送到 `main` / `master` 也会自动构建。
4. 构建成功后，点击任务页面底部的 **Artifacts → SMBPrivateGallery-debug-apk**，解压得到 `app-debug.apk`，发送到手机安装。
5. GitHub Actions 已配置 JDK 17、Gradle 8.9、Android SDK 35、AGP 8.7.3。

本源码没有包含下载的 Gradle Wrapper JAR；GitHub Actions 使用 `gradle/actions/setup-gradle` 自动安装 Gradle。Android Studio 可直接打开项目进行同步构建；本地 CLI 需安装 Gradle 8.9 或自行生成 Wrapper。

## 隐私声明（务必阅读）

“**不留下痕迹**”在本项目中指**应用主动产生的手机本地痕迹**：不写入图片、缩略图、观看历史、密码、App 日志或其他媒体文件。它不等于物理层面彻底无痕。Android 的系统诊断/输入法、SMB 主机访问日志、网络设备、系统内存残留、他人拍摄屏幕，可能仍有信息。`FLAG_SECURE` 无法防止外部摄像头拍屏。SMB 数据流是否加密取决于双方协商和服务器配置，默认不能声称端到端加密。

由第三方 SDK/库及 Android 系统自身产生的运行时行为，无法仅凭本源码验证完全不存在；敏感场景请使用独立访客账号和受信任局域网。

## 已知限制

- 已测试源码结构与配置的静态一致性；**未在此环境执行 Android Gradle 构建或真机 SMB 测试**，请用 Actions 的构建结果验证。
- 动态 GIF 只显示静态首帧；HEIC/AVIF 支持取决于手机 Android 系统内置解码器。
- 每张图片首次显示需要从 SMB 读取数据，超大原图及旧路由器 SMB 设备可能较慢。
- 旋转视图后部分 SMB 图片的 EXIF 方向信息未单独校正。
- 不支持 SMB1，某些只支持 SMB3.1.1 且禁止向下协商的服务器也可能不兼容 jcifs-ng 2.1.10。
- 断开连接及 App 结束不保存会话；下次需要重新输入地址和密码，这是隐私取舍。

## 技术实现

- Java 17, Android SDK 35, minSdk 26, targetSdk 35
- [jcifs-ng 2.1.10](https://github.com/AgNO3/jcifs-ng) (SMB2 / 部分 SMB3)、`slf4j-nop`，不嵌入广告/分析 SDK
- 图片使用 `BitmapFactory.decodeStream` 直接从 SMB 网络流解码到 RAM；通过采样避免把极高分辨率原图完整解压到内存
- 只读 SMB、没有本地文件 I/O、没有使用 `ACTION_VIEW` Intent

## 权限

仅有 `android.permission.INTERNET`，用于连入局域网 SMB 服务器。targetSdk 35 在 Android 17 下仍享有官方说明的局域网旧目标兼容行为。将来升级 targetSdk 37 时，需要按官方文档添加 `ACCESS_LOCAL_NETWORK` 运行时权限。
